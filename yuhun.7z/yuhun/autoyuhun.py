# -*- encoding=utf8 -*-
__author__ = "z"

from airtest.core.api import *
from airtest.core.helper import *
from airtest.cli.parser import cli_setup

# from yuhun.myapi import *


if not cli_setup():
    auto_setup(__file__, logdir=False, devices=[
        "Android://127.0.0.1:5037/192.168.10.104:5555",
        # "Windows:///656912",
        "Android://127.0.0.1:5037/127.0.0.1:7555",
    ])

devA = G.DEVICE_LIST[0]
devI = G.DEVICE_LIST[1]

def switchDev():
   if G.DEVICE == devA:
       G.DEVICE = devI
       print("切换到设备mumu")
   elif G.DEVICE == devI:
       print("切换到设备一加")
       G.DEVICE = devA

if __name__ == '__main__':
    while True:

        zuoshang = Template("pic/zuoshang.png")
        jiangli = Template("pic/jiangli.png")
        tiaozhan = Template("pic/zhunbei.png")

        if exists(jiangli):
            print("找到了奖励")
            touch(jiangli)

        if exists(zuoshang):
            print("遇到返回，暂停扫描......")
            sleep(5)

        if exists(tiaozhan):
            print("找到了挑战")
            touch(tiaozhan)
            sleep(15)

        # gu = Template("pic/gu.png")
        # if gu:
        #     print("找到了鼓")
        #     touch(gu)
        #     sleep(2)

        if exists(jiangli):
            print("找到了奖励")
            touch(jiangli)

        switchDev()
